Bestemmie.org Python API
=============================

Simple Bestemmie.org rest api wrapper

----

To install ::
	pip install bestemmie
	
----

Use ::
	import bestemmie
	